#include "bookparser.h"
#include <QFile>              // 用于文件操作
#include <QTextStream>        // 用于以文本流方式读写文件
#include <QStringConverter>   // 包含文本编码转换功能
#include <QRegularExpression> // 用于处理正则表达式，以分割单词

// 解析单本书籍文件的方法
// path: 文件路径
// title: 书名
// fullText: 输出参数，用于返回整本书的文本内容
QVector<BookEntry> BookParser::parseBook(const QString &path, const QString &title, QString &fullText)
{
    QVector<BookEntry> results; // 存储解析结果的向量
    QFile file(path);           // 创建 QFile 对象以操作文件

    // 尝试以只读文本模式打开文件
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        // 重要：如果文件打开失败，打印警告信息。这对于调试文件路径问题非常有用。
        qWarning() << "Could not open file:" << path;
        return results; // 返回空的向量
    }

    QTextStream in(&file); // 创建 QTextStream 对象，用于读取文件内容
    // 设置文本流的编码为 UTF-8。这对于正确读取包含非 ASCII 字符的文本文件至关重要。
    // `setEncoding` 是 Qt 6 中推荐的方法。
    in.setEncoding(QStringConverter::Utf8);
    // in.setCodec("UTF-8"); // 这是 Qt 5 中使用的方法，现在已过时

    QStringList lines;                    // 用于存储文件中的所有行
    QString chapter = "Unknown Chapter";  // 当前章节名，默认为未知
    int page = 1, lineCount = 0, pos = 0; // 页码、行计数器、字符位置计数器

    // 循环读取文件，直到文件末尾
    while (!in.atEnd())
    {
        QString line = in.readLine(); // 读取一行
        lines << line;                // 将当前行添加到行列表中，以便之后拼接成全文

        // 简单地通过检查行是否以 "Chapter" 开头来确定章节（不区分大小写）
        if (line.startsWith("Chapter", Qt::CaseInsensitive))
            chapter = line.trimmed(); // 如果是章节标题，更新当前章节名并去除两端空白

        // 这是一个简化的分页逻辑：每 40 行算作一页
        if (++lineCount % 40 == 0)
            ++page;

        // 使用正则表达式 `\\W+` (一个或多个非单词字符) 来分割行中的单词
        // Qt::SkipEmptyParts 表示忽略分割后产生的空字符串
        QStringList words = line.split(QRegularExpression("\\W+"), Qt::SkipEmptyParts);

        // 遍历分割出的所有单词
        for (const QString &word : words)
        {
            // 为每个单词创建一个 BookEntry 结构体
            BookEntry e{word, page, chapter, title, pos};
            results.append(e); // 将该条目添加到结果向量中
        }

        // 更新字符位置计数器。`+1` 是为了计算换行符 `\n`
        pos += line.length() + 1;
    }

    // 将之前存储的所有行用换行符 `\n` 连接起来，形成完整的文本
    fullText = lines.join("\n");
    return results; // 返回包含所有单词条目的向量
}