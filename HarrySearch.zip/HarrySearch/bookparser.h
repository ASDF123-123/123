#ifndef BOOKPARSER_H
#define BOOKPARSER_H

#include <QString>
#include <QVector>

// 定义一个结构体 BookEntry，用于存储关于书中一个单词的信息
struct BookEntry
{
    QString word;       // 单词本身
    int page;           // 单词所在的页码
    QString chapter;    // 单词所在的章节
    QString bookTitle;  // 单词所属的书名
    int positionInText; // 单词在整本书文本中的起始位置（字符索引）
};

// BookParser 类负责将书籍文本文件解析成一系列的 BookEntry
class BookParser
{
public:
    // 解析指定路径的书籍文件
    // path: 文件路径
    // title: 书名
    // fullText: 一个输出参数，方法执行后会包含整本书的文本内容
    // 返回值: 一个包含书中所有单词信息的 QVector<BookEntry>
    QVector<BookEntry> parseBook(const QString &path, const QString &title, QString &fullText);
};

#endif // BOOKPARSER_H