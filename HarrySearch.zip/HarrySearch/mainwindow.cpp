#include "mainwindow.h"    // 包含主窗口的头文件
#include "ui_mainwindow.h" // 包含由 Qt Designer 生成的 UI 类的头文件
#include <QFileDialog>     // 包含文件对话框类，用于选择文件（此文件中未使用，但可能用于未来功能）
#include <QMessageBox>     // 包含消息框类，用于向用户显示信息（此文件中未使用，但可能用于未来功能）

// MainWindow 类的构造函数
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) // 调用基类构造函数并初始化 ui 指针
{
    ui->setupUi(this); // 设置和初始化由 Qt Designer 创建的 UI 元素

    // 定义一个包含所有书籍文件路径的字符串列表
    QStringList files = {
        "data/Book1.txt", "data/Book2.txt", "data/Book3.txt",
        "data/Book4.txt", "data/Book5.txt", "data/Book6.txt",
        "data/Book7.txt", "data/Book8.txt"};

    // 调用搜索引擎的 loadBooks 方法，加载并解析所有书籍文件
    engine.loadBooks(files);

    // ---- 配置搜索结果表格 ----
    // 设置表格的列数为 4
    ui->resultTable->setColumnCount(4);
    // 定义表头标签
    QStringList headers = {"关键词", "页码", "章节", "书名"};
    // 将表头标签设置到表格中
    ui->resultTable->setHorizontalHeaderLabels(headers);
    // 设置最后一列自动拉伸以填满表格的剩余空间
    ui->resultTable->horizontalHeader()->setStretchLastSection(true);

    // 在程序启动时，自动执行一次搜索，以显示默认结果（关键词硬编码为 "Harry Potter"）
    // on_searchButton_clicked();
}

// MainWindow 类的析构函数
MainWindow::~MainWindow()
{
    delete ui; // 释放 ui 指针，清理 UI 资源
}

// “查询”按钮的点击事件槽函数
void MainWindow::on_searchButton_clicked()
{
    // 从输入框获取用户输入的文本（注意：此行代码的结果被下一行覆盖了）
    QString keyword = ui->searchInput->text();
    // **注意**: 关键词被硬编码为 "Harry Potter"。这意味着无论用户在输入框中输入什么，
    // 程序都将搜索 "Harry Potter"。如果想使用用户的输入，需要注释或删除此行。
    // keyword = "Harry Potter";

    // 使用搜索引擎执行搜索，并将结果存储在 currentResults 成员变量中
    currentResults = engine.search(keyword);

    // 根据搜索结果的数量，设置表格的行数
    ui->resultTable->setRowCount(currentResults.size());

    // 遍历所有搜索结果
    for (int i = 0; i < currentResults.size(); ++i)
    {
        const BookEntry &entry = currentResults[i]; // 获取当前行的搜索结果条目
        qDebug() << entry.word << ' ' << entry.page << ' ' << entry.chapter << ' ' << entry.bookTitle;
        // 在表格的第 i 行、第 0 列创建一个新的表格项，并显示关键词
        ui->resultTable->setItem(i, 0, new QTableWidgetItem(entry.word));
        // 在表格的第 i 行、第 1 列创建一个新的表格项，并显示页码（需要将 int 转换为 QString）
        ui->resultTable->setItem(i, 1, new QTableWidgetItem(QString::number(entry.page)));
        // 在表格的第 i 行、第 2 列创建一个新的表格项，并显示章节
        ui->resultTable->setItem(i, 2, new QTableWidgetItem(entry.chapter));
        // 在表格的第 i 行、第 3 列创建一个新的表格项，并显示书名
        ui->resultTable->setItem(i, 3, new QTableWidgetItem(entry.bookTitle));
    }

    // 清空下方的上下文文本框
    ui->textContext->clear();

    // 在调试输出中打印一条消息，方便调试
    qDebug() << "search click";
}

// 结果表格的单元格点击事件槽函数
void MainWindow::on_resultTable_cellClicked(int row, int /*column*/) // column 参数未使用，可以忽略
{
    // 检查点击的行号是否有效，防止越界访问
    if (row < 0 || row >= currentResults.size())
        return;

    // 根据行号从 `currentResults` 中获取对应的搜索结果条目
    // 然后调用搜索引擎的 `getContext` 方法来获取该条目所在的上下文（前后段落）
    QString context = engine.getContext(currentResults[row]);

    // 将获取到的上下文文本显示在下方的 QTextEdit 控件中
    ui->textContext->setPlainText(context);
}