#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>    // 包含 QMainWindow 基类
#include "searchengine.h" // 包含我们自己定义的 SearchEngine 类

// Qt 的命名空间，由 uic (UI 编译器) 自动生成
QT_BEGIN_NAMESPACE
namespace Ui
{
    class MainWindow;
}
QT_END_NAMESPACE

// MainWindow 类定义，继承自 QMainWindow
class MainWindow : public QMainWindow
{
Q_OBJECT // 宏，用于启用 Qt 的信号与槽机制

    public :
    // 构造函数，parent 指针用于指定父窗口，默认为 nullptr
    MainWindow(QWidget *parent = nullptr);
    // 析构函数
    ~MainWindow();

    // 私有槽函数，用于响应 UI 事件
private slots:
    // 当 "查询" 按钮被点击时调用的槽函数
    void on_searchButton_clicked();
    // 当结果表格中的单元格被点击时调用的槽函数
    void on_resultTable_cellClicked(int row, int column);

    // 私有成员变量
private:
    Ui::MainWindow *ui;                // 指向由 Qt Designer 生成的 UI 类的实例，用于访问界面上的控件
    SearchEngine engine;               // 搜索引擎类的实例，负责所有后台逻辑
    QVector<BookEntry> currentResults; // 存储当前一次搜索的结果，方便在点击单元格时快速查找
};
#endif // MAINWINDOW_H