#include "searchengine.h" // 包含搜索引擎的头文件
#include "textutils.h"    // 包含文本工具类的头文件
#include <QFileInfo>      // 包含文件信息类，用于从路径中提取文件名等信息
#include <QRegularExpression>

// 加载并解析书籍文件
void SearchEngine::loadBooks(const QStringList &paths)
{
    BookParser parser; // 创建一个书籍解析器实例
    // 遍历传入的文件路径列表
    for (const QString &path : paths)
    {
        QFileInfo info(path);            // 创建文件信息对象
        QString title = info.baseName(); // 从文件名中提取基础名称（不含扩展名）作为书名

        QString text; // 用于接收解析出的书籍全文
        // 调用解析器的 parseBook 方法，解析书籍文件
        // 它会返回该书的所有单词条目（BookEntry），并通过引用参数 `text` 返回书籍的全文
        QVector<BookEntry> result = parser.parseBook(path, title, text);

        // 将当前这本书解析出的所有条目追加到总的 `entries` 向量中
        entries += result;
        // 将当前这本书的标题和全文内容存入 `fullTexts` 映射中
        fullTexts[title] = text;
    }
}

QVector<BookEntry> SearchEngine::search(const QString &keyword)
{
    QVector<BookEntry> result;

    QStringList searchWords = keyword.split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);

    if (searchWords.isEmpty())
    {
        qDebug() << "搜索关键词为空，搜索中止。";
        return result;
    }

    qDebug() << "开始搜索，关键词:" << keyword << "，在" << entries.size() << "个条目中查找。";

    for (int i = 0; i <= entries.size() - searchWords.size(); ++i)
    {
        bool match = true;

        for (int j = 0; j < searchWords.size(); ++j)
        {

            if (entries[i + j].word.compare(searchWords[j], Qt::CaseInsensitive) != 0)
            {
                match = false;
                break;
            }
        }

        if (match)
        {
            result << entries[i];
        }
    }

    // 对搜索结果按页码排序
    std::sort(result.begin(), result.end(), [](const BookEntry &a, const BookEntry &b)
              { return a.page < b.page; });

    qDebug() << "搜索完成，找到" << result.size() << "个匹配项。";
    return result;
}

// 获取指定条目的上下文文本
QString SearchEngine::getContext(const BookEntry &entry)
{
    // 检查 `fullTexts` 映射中是否包含该条目所属的书籍
    if (!fullTexts.contains(entry.bookTitle))
        return ""; // 如果不包含，返回空字符串

    // 如果包含，则调用 TextUtils 工具类的 extractParagraphs 方法
    // 传入该书的全文和关键词在文中的位置，以提取上下文
    return TextUtils::extractParagraphs(fullTexts[entry.bookTitle], entry.positionInText);
}