#ifndef SEARCHENGINE_H
#define SEARCHENGINE_H

#include "bookparser.h" // 包含书籍解析器的头文件，以使用 BookEntry 结构
#include <QMap>         // 包含 QMap 类，用于存储书名到全文内容的映射
#include <QVector>      // 包含 QVector 类，用于存储搜索结果

// SearchEngine 类负责加载书籍数据、执行搜索和提供上下文
class SearchEngine
{
public:
    // 加载并解析指定路径列表中的所有书籍文件
    void loadBooks(const QStringList &filePaths);

    // 根据给定的关键词搜索所有已加载的书籍
    // 返回一个包含所有匹配项的 QVector<BookEntry>
    QVector<BookEntry> search(const QString &keyword);

    // 根据一个 BookEntry 条目，获取其在原文中的上下文（前后段落）
    QString getContext(const BookEntry &entry);

private:
    // 一个 QVector，用于存储从所有书籍中解析出的所有 BookEntry 条目
    QVector<BookEntry> entries;

    // 一个 QMap，用于存储每本书的完整文本内容
    // 键(key)是书的标题（QString），值(value)是书的全文（QString）
    QMap<QString, QString> fullTexts;
};

#endif // SEARCHENGINE_H