#include "textutils.h"
#include <QString>
#include <QStringList>

// 实现提取上下文段落的静态方法
QString TextUtils::extractParagraphs(const QString &text, int position)
{
    // 将整个文本按两个换行符 `\n\n` 分割成段落列表。这是一种常见的段落划分方式。
    QStringList paras = text.split("\n\n", Qt::SkipEmptyParts);
    int current = 0, index = -1; // `current` 记录当前遍历到的字符位置, `index` 记录目标段落的索引

    // 遍历所有段落，以找到包含 `position` 的那一段
    for (int i = 0; i < paras.size(); ++i)
    {
        // `current` 累加当前段落的长度和两个换行符的长度
        current += paras[i].length() + 2;

        // 如果累加后的位置超过了目标位置 `position`，说明目标词就在这个段落里
        if (current > position)
        {
            index = i; // 记录下这个段落的索引
            break;     // 找到了就退出循环
        }
    }

    QString result; // 用于存储最终的上下文文本

    // 如果找到了目标段落 (index 有效)
    if (index != -1)
    {
        // 如果目标段落不是第一段，则将前一段也加入结果中，并加上段落分隔符
        if (index > 0)
            result += paras[index - 1] + "\n\n";

        // 将目标段落本身加入结果中，并加上段落分隔符
        result += paras[index] + "\n\n";

        // 如果目标段落不是最后一段，则将后一段也加入结果中
        if (index + 1 < paras.size())
            result += paras[index + 1];
    }

    return result; // 返回拼接好的上下文文本
}