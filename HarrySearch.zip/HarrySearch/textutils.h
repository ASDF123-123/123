#ifndef TEXTUTILS_H
#define TEXTUTILS_H

#include <QString>

// TextUtils 类提供静态的文本处理工具函数
class TextUtils
{
public:
    // 静态方法，用于从大段文本中提取指定位置周围的段落作为上下文
    // text: 完整的文本内容
    // position: 关键词在文本中的字符位置
    // 返回值: 包含上下文的字符串 (通常是关键词所在段落及其前后段落)
    static QString extractParagraphs(const QString &text, int position);
};

#endif // TEXTUTILS_H