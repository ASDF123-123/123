#include "fizzbuzz.h"
std::string fizzBuzz(int value)
{
	if (value % 3 == 0 && value % 5 == 0)
		return "FizzBuzz";
	if (value % 3 == 0)
		return "Fizz";
	if (value % 5 == 0)
		return "Buzz";
	if (value % 3 != 0 && value % 5 != 0)
		return std::to_string(value);
}
