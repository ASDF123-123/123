#include<iostream>
#include"fizzbuzz.h"
using namespace std;
int main()
{
	int value;
	cin >> value;
	cout << fizzBuzz(value) << endl;
	return 0;
}