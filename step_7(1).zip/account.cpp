//account.cpp
#include "account.h"
#include <cmath>
#include <iostream>
#include <iomanip>
using namespace std;
double Account::total = 0;
multimap<Date, AccountRecord> Account::recordMap;

// AccountRecordʵ��
AccountRecord::AccountRecord(const Date& date, Account* account,
    double amount, double balance, const string& desc)
    : date(date), account(account), amount(amount), balance(balance), desc(desc) {}

void AccountRecord::show() const {
    cout << date << "\t#" << account->getId() << "\t" << amount
        << "\t" << balance << "\t" << desc << endl;
}

Account::Account(const Date& date, const string& id)
    : id(id), balance(0), lastDate(date), acc(date, 0) {}

// ��¼����
void Account::record(const Date& date, double amount, const string& desc) {
    AccountRecord record(date, this, amount, balance, desc);
    recordMap.insert(make_pair(date, record));
}

// ��ѯ��ʷ��Ŀ
void Account::query(const Date& date1, const Date& date2) {
    if (date2 < date1) {
        cout << "Invalid date range: end date is earlier than start date" << endl;
        return;
    }

    multimap<Date, AccountRecord>::iterator it;
    for (it = recordMap.lower_bound(date1); it != recordMap.upper_bound(date2); ++it) {
        it->second.show();
    }
}

SavingsAccount::SavingsAccount(const Date& date, const string& id, double rate)
    : Account(date, id), rate(rate) {
    cout << date << "\t#" << id << " created" << endl;
}

void SavingsAccount::deposit(const Date& date, double amount, const string& desc) {
    if (amount <= 0)//������Ϊ����
        throw AccountException(this, "Deposit amount must be positive");
    amount = floor(amount * 100 + 0.5) / 100;
    balance += amount;
    total += amount;
    acc.change(date, balance);
    lastDate = date;

    // ��¼����
    record(date, amount, desc);

    cout << date << "\t#" << id << "\t" << amount
        << "\t" << balance << "\t" << desc << endl;
}

void SavingsAccount::withdraw(const Date& date, double amount, const string& desc) {
    if (amount <= 0)//ȡ�����Ϊ����
        throw AccountException(this, "Withdrawal amount must be positive");
    amount = floor(amount * 100 + 0.5) / 100;
    if (amount > balance)//�䶯�����ܴ��ڴ����˻����
        throw AccountException(this, "Insufficient funds");
    
    balance -= amount;
    total -= amount;
    acc.change(date, balance);
    lastDate = date;

    // ��¼����
    record(date, -amount, desc);

    cout << date << "\t#" << id << "\t" << -amount << "\t" << balance << "\t" << desc << endl;
}

void SavingsAccount::settle(const Date& date) {
    if (date.getMonth() == 1 && date.getDay() == 1) {
        double interest = acc.getSum(date) * rate / 366;
        if (abs(interest) > 1e-5) {
            interest = floor(interest * 100 + 0.5) / 100;
            balance += interest;
            total += interest;

            // ��¼��Ϣ
            record(date, interest, "interest");

            cout << date << "\t#" << id << "\t" << interest << "\t" << balance << "\t" << "interest" << endl;
        }
        acc.reset(date, balance);
    }
}

void SavingsAccount::show() const {
    cout << id << "\tBalance: " << balance;
}

CreditAccount::CreditAccount(const Date& date, const string& id,
    double credit, double rate, double fee)
    : Account(date, id), credit(credit), rate(rate), fee(fee) {
    cout << date << "\t#" << id << " created" << endl;
}

void CreditAccount::deposit(const Date& date, double amount, const string& desc) {
    if (amount <= 0)//������Ϊ����
        throw AccountException(this, "Deposit amount must be positive");
    amount = floor(amount * 100 + 0.5) / 100;
    balance += amount;
    total += amount;
    double debt = (balance < 0) ? -balance : 0;
    acc.change(date, debt);
    lastDate = date;

    // ��¼����
    record(date, amount, desc);

    cout << date << "\t#" << id << "\t" << amount << "\t" << balance << "\t" << desc << endl;
}

void CreditAccount::withdraw(const Date& date, double amount, const string& desc) {
    if (amount <= 0)//����Ϊ����
        throw AccountException(this, "Withdrawal amount must be positive");
    amount = floor(amount * 100 + 0.5) / 100;
    if (amount > getAvailableCredit())//�䶯�����ܴ��������˻����
        throw AccountException(this, "Exceeds credit limit");
    balance -= amount;
    total -= amount;
    double debt = (balance < 0) ? -balance : 0;
    acc.change(date, debt);
    lastDate = date;

    // ��¼����
    record(date, -amount, desc);

    cout << date << "\t#" << id << "\t" << -amount << "\t" << balance << "\t" << desc << endl;
}

void CreditAccount::settle(const Date& date) {
    double interest = acc.getSum(date) * rate;
    if (abs(interest) > 1e-5) {
        interest = floor(interest * 100 + 0.5) / 100;
        balance -= interest;
        total -= interest;

        // ��¼��Ϣ
        record(date, -interest, "interest");

        cout << date << "\t#" << id << "\t" << -interest << "\t" << balance << "\t" << "interest" << endl;
    }

    if (date.getMonth() == 1 && date.getDay() == 1) {
        balance -= fee;
        total -= fee;

        // ��¼���
        record(date, -fee, "annual fee");

        cout << date << "\t#" << id << "\t" << -fee << "\t" << balance << "\t" << "annual fee" << endl;
    }

    double debt = (balance < 0) ? -balance : 0;
    acc.reset(date, debt);
}

void CreditAccount::show() const {
    cout << id << "\tBalance: " << balance
        << "\tAvailable credit: " << getAvailableCredit();
}