//account.h
#ifndef __ACCOUNT_H__
#define __ACCOUNT_H__

#include "date.h"
#include "accumulator.h"
#include <string>
#include <iostream>
#include <map>
#include <stdexcept>
using namespace std;
class Account;

// ��Ŀ��¼��
class AccountRecord {
public:
    Date date;      // ����
    Account* account; // �˻�
    double amount;  // ���
    double balance; // ���
    string desc;    // ����

    AccountRecord(const Date& date, Account* account, double amount,
        double balance, const string& desc);
    void show() const;
};

class Account {
protected:
    string id;          // �˺�
    double balance;     // ���
    Date lastDate;      // �ϴα����������
    Accumulator acc;    // �ۼ���
    static double total;// �����˻����ܽ��

    // ��¼����
    void record(const Date& date, double amount, const string& desc);

public:
    // ��̬��Ա - �����˻��Ľ��׼�¼
    static multimap<Date, AccountRecord> recordMap;

    Account(const Date& date, const string& id);
    virtual ~Account() {}

    // ���麯��
    virtual void deposit(const Date& date, double amount, const string& desc) = 0;
    virtual void withdraw(const Date& date, double amount, const string& desc) = 0;
    virtual void settle(const Date& date) = 0;
    virtual void show() const = 0;

    // ��ѯ��ʷ��Ŀ
    static void query(const Date& date1, const Date& date2);

    const string& getId() const { return id; }
    double getBalance() const { return balance; }
    static double getTotal() { return total; }
};

class SavingsAccount : public Account {
private:
    double rate; // ������
public:
    SavingsAccount(const Date& date, const string& id, double rate);
    void deposit(const Date& date, double amount, const string& desc);
    void withdraw(const Date& date, double amount, const string& desc);
    void settle(const Date& date);
    void show() const;
};

class CreditAccount : public Account {
private:
    double credit; // ���ö��
    double rate;   // �����ʣ�Ƿ�������ʣ�
    double fee;    // ���
    double getAvailableCredit() const { return credit + balance; } // �������ö��
public:
    CreditAccount(const Date& date, const string& id, double credit, double rate, double fee);
    void deposit(const Date& date, double amount, const string& desc);
    void withdraw(const Date& date, double amount, const string& desc);
    void settle(const Date& date);
    void show() const;
};
// �˻��쳣��
class AccountException : public runtime_error {
private:
    const Account* account; // �����쳣���˻�
public:
    AccountException(const Account* account, const string& msg)
        : runtime_error(msg), account(account) {}
    const Account* getAccount() const { return account; }
};

#endif