//accumulator.h
#ifndef __ACCUMULATOR_H__
#define __ACCUMULATOR_H__

#include "date.h"
using namespace std;
class Accumulator {
private:
    Date lastDate;  // �ϴα������
    double value;   // ��ǰֵ
    double sum;     // �ۼ�ֵ
public:
    Accumulator(const Date& date, double value)
        : lastDate(date), value(value), sum(0) {}

    // ��ȡ��ָ�����ڵ��ۼ�ֵ
    double getSum(const Date& date) const {
        return sum + value * (date - lastDate);
    }

    // �����ǰֵ
    void change(const Date& date, double newValue) {
        sum = getSum(date);
        lastDate = date;
        value = newValue;
    }

    // �����ۼ���
    void reset(const Date& date, double newValue) {
        lastDate = date;
        value = newValue;
        sum = 0;
    }
};

#endif