//date.cpp
#include "date.h"
#include <stdexcept>
#include <iostream>
using namespace std;
const int Date::DAYS_BEFORE_MONTH[13] = {
    0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365
};

Date::Date() : year(1900), month(1), day(1) {}

Date::Date(int y, int m, int d) : year(y), month(m), day(d) {
    if (month < 1 || month > 12)//����·ݺ�����
    {
        throw runtime_error("Invalid month");
    }
    if (day < 1 || day > getMaxDay()) //�������ں�����
    {
        throw runtime_error("Invalid day");
    }
}
Date Date::read(istream& in) {
    int y, m, d;
    in >> y >> m >> d;
    return Date(y, m, d);
}
int Date::getMaxDay() const {
    static const int maxDays[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    if (month == 2 && isLeapYear(year)) {
        return 29;
    }
    return maxDays[month - 1];
}

bool Date::isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

void Date::show() const {
    cout << year << "-" << month << "-" << day;
}

Date Date::read() {
    int y, m, d;
    cin >> y >> m >> d;
    return Date(y, m, d);
}

ostream& operator << (ostream& out, const Date& date) {
    out << date.year << "-" << date.month << "-" << date.day;
    return out;
}

int Date::operator - (const Date& other) const {
    // �����������ڸ��Ե����������ӹ�Ԫ1��1��1�տ�ʼ��
    auto calcDays = [](int y, int m, int d) {
        int days = (y - 1) * 365 + DAYS_BEFORE_MONTH[m - 1] + d;
        // ������������
        for (int i = 1; i < y; i++) {
            if (isLeapYear(i)) days++;
        }
        // ��ǰ�����������·�>2
        if (m > 2 && isLeapYear(y)) days++;
        return days;
        };

    return calcDays(year, month, day) - calcDays(other.year, other.month, other.day);
}