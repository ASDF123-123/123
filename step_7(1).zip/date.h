//date.h
#ifndef __DATE_H__
#define __DATE_H__

#include <iostream>
#include <stdexcept>
using namespace std;
class Date {
private:
    int year;
    int month;
    int day;
    static const int DAYS_BEFORE_MONTH[13];
public:
    Date();
    Date(int y, int m, int d);
    void show() const;
    int getYear() const { return year; }
    int getMonth() const { return month; }
    int getDay() const { return day; }
    int getMaxDay() const;

    // ����<�����֧������
    bool operator < (const Date& other) const {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }

    int operator - (const Date& date) const;
    static bool isLeapYear(int year);
    friend ostream& operator << (ostream& out, const Date& date);

    // ����read����
    static Date read();
    static Date read(istream& in);
};

#endif