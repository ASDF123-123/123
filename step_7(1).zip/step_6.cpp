#include "account.h"
#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace std;

struct deleter {
    template <class T> void operator () (T* p) { delete p; }
};

// ִ������ĺ���
void executeCommand(char cmd, istringstream& iss, Date& date, vector<Account*>& accounts) {
    char type;
    int index, day;
    double amount, credit, rate, fee;
    string id, desc;
    Account* account;
    Date date1, date2;
    try{
    switch (cmd) {
    case 'a'://�����˻�
        iss >> type >> id;
        if (type == 's') {
            iss >> rate;
            account = new SavingsAccount(date, id, rate);
            accounts.push_back(account);
        }
        else {
            iss >> credit >> rate >> fee;
            account = new CreditAccount(date, id, credit, rate, fee);
            accounts.push_back(account);
        }
        break;
    case 'd'://�����ֽ�
        iss >> index >> amount;
        getline(iss, desc); // ��ȡʣ�ಿ����Ϊ����
        if (index >= 0 && index < accounts.size()) {
            accounts[index]->deposit(date, amount, desc);
        }
        break;
    case 'w'://ȡ���ֽ�
        iss >> index >> amount;
        getline(iss, desc);
        if (index >= 0 && index < accounts.size()) {
            accounts[index]->withdraw(date, amount, desc);
        }
        break;
    case 's'://��ѯ���˻���Ϣ
        for (size_t i = 0; i < accounts.size(); i++) {
            cout << "[" << i << "] ";
            accounts[i]->show();
            cout << endl;
        }
        break;
    case 'c'://�ı�����
        iss >> day;
        if (day < date.getDay())
            throw runtime_error("Cannot set to a previous day");
        else if (day > date.getMaxDay())
            throw runtime_error("Invalid day");
        else
            date = Date(date.getYear(), date.getMonth(), day);
        break;
    case 'n'://�����¸���
        if (date.getMonth() == 12)
            date = Date(date.getYear() + 1, 1, 1);
        else
            date = Date(date.getYear(), date.getMonth() + 1, 1);
        for (vector<Account*>::iterator iter = accounts.begin(); iter != accounts.end(); ++iter)
            (*iter)->settle(date);
        break;
    case 'q'://��ѯһ��ʱ���ڵ���Ŀ
        date1 = Date::read(iss);
        date2 = Date::read(iss);
        Account::query(date1, date2);
        break;
    }
   }catch (const AccountException& e) {
        // �˻������쳣
        cerr << "Account Error (" << e.getAccount()->getId() << "): " << e.what() << endl;
        throw; // �����׳�������ѭ��֪������ʧ��
    }
    catch (const runtime_error& e) {
        // ���ڵ�����ʱ����
        cerr << "Error: " << e.what() << endl;
        throw; // �����׳�
    }
}

int main() {
    Date date(2008, 11, 1); // ��ʼ����
    vector<Account*> accounts; // �����˻�����
    const string commandFile = "commands.txt";

    // 1. �ָ�֮ǰ���������
    ifstream infile(commandFile);
    if (infile) {
        string line;
        while (getline(infile, line)) {
            if (!line.empty()) {
                istringstream iss(line);
                char cmd;
                iss >> cmd;
                try {
                    executeCommand(cmd, iss, date, accounts);
                }
                catch (...) {
                    cerr << "Error processing saved command: " << line << endl;
                }
            }
        }
        infile.close();
    }

    // 2. �������ļ�׼��׷��������
    ofstream outfile(commandFile, ios::app);
    if (!outfile) {
        cerr << "Error: cannot open command file for writing" << endl;
    }

    cout << "(a)add account (d)deposit (w)withdraw (s)show (c)change day (n)next month (q)query (e)exit" << endl;
    char cmd;
    do {
        // ��ʾ���ں��ܽ��
        date.show();
        cout << "\tTotal: " << Account::getTotal() << "\tcommand> ";

        string inputLine;
        getline(cin, inputLine);
        if (inputLine.empty()) continue;

        istringstream iss(inputLine);
        iss >> cmd;

        // 3. �������������
        if (cmd != 'e') {
            bool success = true;
            try {
                executeCommand(cmd, iss, date, accounts);
            }
            catch (const AccountException& e) {
                success = false;
            }
            catch (const runtime_error& e) {
                success = false;
            }

            // ���浽�ļ����ų���ѯ����ʾ��ʧ�����
            if (success && cmd != 's' && cmd != 'q' && outfile) {
                outfile << inputLine << endl;
            }
        }
    } while (cmd != 'e');

    if (outfile) outfile.close();

    // ������Դ
    for_each(accounts.begin(), accounts.end(), deleter());
    return 0;
}