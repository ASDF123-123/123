#include <windows.h>
#include <iostream>
#include "abc.h"

using namespace std;

void gotoXY(int x, int y) {
    COORD pos = { (SHORT)x, (SHORT)y };
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void hide() {
    CONSOLE_CURSOR_INFO cursor_info = { 1, 0 };
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
}

void borders() {
    const int width = 55;
    const int height = 35;

    // ���ƶ����͵ײ��߿�
    for (int i = 0; i < width; i++) {
        gotoXY(i, 0); cout << "-";
        gotoXY(i, height); cout << "-";
    }

    // �������ұ߿�
    for (int i = 0; i <= height; i++) {
        gotoXY(0, i); cout << "|";
        gotoXY(width, i); cout << "|";
    }

    // ���Ʒ�������߿�
    gotoXY(width + 1, 0); cout << "+";
    gotoXY(width + 1, height); cout << "+";
    for (int i = width + 1; i < width + 15; i++) {
        gotoXY(i, 0); cout << "-";
        gotoXY(i, height); cout << "-";
    }
    for (int i = 1; i < height; i++) {
        gotoXY(width + 15, i); cout << "|";
    }

    // ���ӷ�������
    gotoXY(width + 2, 1); cout << "SCORE BOARD";
}