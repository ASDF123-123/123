#ifndef ABC_H
#define ABC_H

void gotoXY(int x, int y);
void hide();
void borders();

#endif
