#include "game.h"
#include "abc.h"
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cstdlib>
#include <ctime>

using namespace std;

const int Game::width = 55;
const int Game::height = 35;
const int Game::max = 50;

Game::Game() : score(0), gameOver(false) {
    myPlane = { width / 2, height - 3 };
}

void Game::init() {
    system("cls");
    hide();
    borders();
    srand((unsigned)time(nullptr));
}

// ��Ļ���庯��
void Game::addToBuffer(char* buffer, Position p, bool isPlane) {
    if (p.y >= 1 && p.y < height && p.x >= 2 && p.x < width - 2) {
        if (isPlane) {
            // �ɻ���״
            buffer[(p.y - 1) * width + (p.x - 1)] = '/';
            buffer[(p.y - 1) * width + (p.x)] = '=';
            buffer[(p.y - 1) * width + (p.x + 1)] = '\\';

            buffer[p.y * width + (p.x - 2)] = '<';
            buffer[p.y * width + (p.x - 1)] = '<';
            buffer[p.y * width + (p.x)] = '*';
            buffer[p.y * width + (p.x + 1)] = '>';
            buffer[p.y * width + (p.x + 2)] = '>';

            buffer[(p.y + 1) * width + (p.x - 2)] = '*';
            buffer[(p.y + 1) * width + (p.x - 1)] = ' ';
            buffer[(p.y + 1) * width + (p.x)] = ' ';
            buffer[(p.y + 1) * width + (p.x + 1)] = ' ';
            buffer[(p.y + 1) * width + (p.x + 2)] = '*';
        }
        else {
            // �л���״
            buffer[(p.y - 1) * width + (p.x - 1)] = '\\';
            buffer[(p.y - 1) * width + (p.x)] = '+';
            buffer[(p.y - 1) * width + (p.x + 1)] = '/';

            buffer[p.y * width + (p.x)] = '|';
        }
    }
}

void Game::addBulletToBuffer(char* buffer, Position b, bool isMyBullet) {
    if (b.y >= 1 && b.y < height && b.x >= 1 && b.x < width) {
        buffer[b.y * width + b.x] = '|';
    }
}

void Game::drawFromBuffer(char* buffer) {
    for (int y = 1; y < height; y++) {
        for (int x = 1; x < width; x++) {
            char c = buffer[y * width + x];
            if (c != ' ') {
                gotoXY(x, y);
                cout << c;
            }
        }
    }
}

// ����Ϸѭ��
void Game::run() {
    // ������Ļ������
    char* screenBuffer = new char[width * height];
    for (int i = 0; i < width * height; i++) {
        screenBuffer[i] = ' ';
    }

    // ���Ƴ�ʼ�߿�
    borders();

    while (!gameOver) {
        clearScreen();
        // ������Ļ�������������߿�
        for (int y = 1; y < height; y++) {
            for (int x = 1; x < width; x++) {
                screenBuffer[y * width + x] = ' ';
            }
        }

        // ��������
        processInput();
        // ������Ϸ״̬
        updateBullets();
        updateEnemies();
        spawnEnemy();

        // ����ϷԪ�����ӵ�������
        addToBuffer(screenBuffer, myPlane, true);
        for (auto& e : enemies) addToBuffer(screenBuffer, e, false);
        for (auto& b : myBullets) addBulletToBuffer(screenBuffer, b, true);
        for (auto& b : enemyBullets) addBulletToBuffer(screenBuffer, b, false);

        // �ӻ��������Ƶ���Ļ
        drawFromBuffer(screenBuffer);
        drawHUD();

        Sleep(50);
    }

    delete[] screenBuffer;
    clearScreen();
    cout << "Game Over! Final Score: " << score << endl;
}

void Game::processInput() {
    if (_kbhit()) {
        char ch = _getch();
        bool moved = false;

        switch (ch) {
        case 'a': if (myPlane.x > 3) { myPlane.x--; moved = true; } break;
        case 'd': if (myPlane.x < width - 3) { myPlane.x++; moved = true; } break;
        case 'w': if (myPlane.y > 1) { myPlane.y--; moved = true; } break;
        case 's': if (myPlane.y < height - 2) { myPlane.y++; moved = true; } break;
        case ' ':
            myBullets.push_back({ myPlane.x, myPlane.y - 2 });
            break;
        case 'q': gameOver = true; break;
        }
    }
}

void Game::updateBullets() {
    vector<Position> newMyBullets;
    vector<Position> newEnemyBullets;

    // �����ҷ��ӵ�
    for (auto& b : myBullets) {
        b.y--;  // �ӵ����Ϸ�

        if (b.y <= 0) continue;  // ���綪��

        bool hit = false;
        // �ж��Ƿ���ел�
        for (size_t i = 0; i < enemies.size(); i++) {
            int dx = abs(b.x - enemies[i].x);
            int dy = abs(b.y - enemies[i].y);
            if (dx <= 1 && dy <= 1) {
                enemies.erase(enemies.begin() + i);
                score++;   // ���� +1��
                hit = true;
                break;
            }
        }
        if (!hit) newMyBullets.push_back(b);
    }

    // ���µз��ӵ�
    for (auto& b : enemyBullets) {
        b.y+=2;  // �ӵ����·�

        if (b.y >= height) continue;  // ���綪��

        // �ж��Ƿ�����ҷ��ɻ�
        int dx = abs(b.x - myPlane.x);
        int dy = abs(b.y - myPlane.y);
        if (dx <= 2 && dy <= 2) {
            score--;  // ������ -1��
            if (score <= 0) gameOver = true;  // ����Ϊ0��Ϸ����
            continue;  // ����ӵ���ʧ
        }

        newEnemyBullets.push_back(b);
    }

    myBullets = newMyBullets;
    enemyBullets = newEnemyBullets;
}


void Game::spawnEnemy() {
    if (enemies.size() < max && rand() % 10 < 2) {
        int x = rand() % (width - 4) + 2;
        enemies.push_back({ x, 2 });
    }
}

void Game::updateEnemies() {
    vector<Position> newEnemies;
    for (size_t i = 0; i < enemies.size(); i++) {
        auto& e = enemies[i];
        e.y++;

        // �л������߽�ʱ�Ƴ�
        if (e.y >= height - 1) {
            continue;
        }

        if (rand() % 10 < 3) {
            enemyBullets.push_back({ e.x, e.y + 1 });
        }

        newEnemies.push_back(e);
    }
    enemies = newEnemies;
}

void Game::drawHUD() {
    gotoXY(width + 2, 2);
    cout << "Score: " << score << "   ";
}

void Game::clearScreen() {
    system("cls");
}