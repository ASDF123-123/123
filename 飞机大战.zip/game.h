#ifndef GAME_H
#define GAME_H

#include <vector>
using namespace std;
struct Position {
    int x, y;
};

class Game {
public:
    static const int width;
    static const int height;
    static const int max;

    Game();
    void init();
    void run();

private:
    Position myPlane;
    int score;
    bool gameOver;

    vector<Position> enemies;
    vector<Position> myBullets;
    vector<Position> enemyBullets;

    
    void addToBuffer(char* buffer, Position p, bool isPlane);
    void addBulletToBuffer(char* buffer, Position b, bool isMyBullet);
    void drawFromBuffer(char* buffer);

    // ��Ϸ����
    void drawMyPlane(Position p);
    void clearMyPlane(Position p);
    void drawEnemy(Position p);
    void clearEnemy(Position p);
    void drawBullets();
    void clearBullets();
    void updateBullets();
    void updateEnemies();
    void spawnEnemy();
    void processInput();
    void drawHUD();
    void clearScreen();
};

#endif