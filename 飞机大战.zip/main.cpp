#include "game.h"

int main() 
{
    Game game;
    game.init();
    game.run();
    return 0;
}
