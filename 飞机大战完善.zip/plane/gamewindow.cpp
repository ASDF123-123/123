#include "GameWindow.h"
#include <QPainter>
#include <QTimer>
#include <QKeyEvent>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <random>
#include <QRandomGenerator>

GameWindow::GameWindow(QWidget* parent)
    : QMainWindow(parent), planeX(250), planeY(300),score(0),gameOverFlag(false),isPaused(false),
    up(false), down(false),left(false), right(false) {

    setFixedSize(600, 400);
    setWindowTitle("飞机大战");

    initUI();

    gameTimer = new QTimer(this);
    connect(gameTimer, &QTimer::timeout, this, &GameWindow::updateGame);
    gameTimer->start(50); // 每50ms更新一次游戏状态
}

GameWindow::~GameWindow() {
    delete gameTimer;
}

void GameWindow::initUI() {
    scoreLabel = new QLabel(this);
    scoreLabel->setText("Score: 0");
    scoreLabel->setGeometry(10, 10, 100, 20);

    QPushButton* restartButton = new QPushButton("重新开始", this);
    restartButton->setGeometry(500, 350, 80, 40);
    restartButton->setFocusPolicy(Qt::NoFocus);
    connect(restartButton, &QPushButton::clicked, this, &GameWindow::restartGame);
}

void GameWindow::paintEvent(QPaintEvent*) {
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    if (gameOverFlag) {
        painter.drawText(rect(), Qt::AlignCenter, "游戏结束！\n点击“重新开始”");
    } else {
        drawGame(painter);
    }
}

void GameWindow::drawGame(QPainter &painter) {
    // 画我方飞机
    painter.setPen(Qt::blue);
    QFont font("Courier", 10, QFont::Bold);
    painter.setFont(font);

    painter.drawText(planeX, planeY,      " /=\\");
    painter.drawText(planeX, planeY + 12, "<<*>>");
    painter.drawText(planeX, planeY + 24, " *  *");

    // 画敌机
    painter.setPen(Qt::red);
    for (const auto &enemy : enemies) {
        painter.drawText(enemy.left(), enemy.top(), "\\+/");
        painter.drawText(enemy.left(), enemy.top() + 12, " | ");
    }

    // 画子弹
    painter.setPen(Qt::green);
    for (const auto &bullet : bullets) {
        painter.drawText(bullet.left(), bullet.top(), "|");
    }
    // 画敌机子弹
    painter.setPen(Qt::red);
    for (const auto &bullet : enemyBullets) {
        painter.drawText(bullet.left(), bullet.top(), "|");
    }


    updateScore();
}

void GameWindow::updateGame() {
    if (gameOverFlag || isPaused) return;

    // 飞机移动，防止飞出边界
    int speed = 5;
    if (left && planeX > 0) planeX -= speed;
    if (right && planeX + 30 < width()) planeX += speed;
    if (up && planeY > 0) planeY -= speed;
    if (down && planeY + 30 < height()) planeY += speed;

    // 根据积分调整敌机出现概率和下落速度
    int enemyAppearChance = 10 + score / 5;
    if (enemyAppearChance > 30) enemyAppearChance = 30;

    int enemySpeed = 10 + score / 5;
    if (enemySpeed > 25) enemySpeed = 25;

    // 随机生成敌人
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis100(0, 99);
    static std::uniform_int_distribution<> disX(0, width() - 30);

    if (dis100(gen) < 10) {
        int ex = disX(gen);
        enemies.push_back(QRect(ex, 0, 30, 30));
    }

    // 更新敌人位置
    for (auto& enemy : enemies) {
        enemy.moveTop(enemy.top() + 2);
    }

    enemies.erase(std::remove_if(enemies.begin(), enemies.end(),
                                 [this](const QRect& e) {
                                     return e.top() > height();
                                 }), enemies.end());
    //  敌机发射子弹
    int enemyShootChance = 5 + score / 10; // 随得分增加稍微提高发射概率
    if (enemyShootChance > 15) enemyShootChance = 15;

    for (const auto &enemy : enemies) {
        if (QRandomGenerator::global()->bounded(100) < enemyShootChance) {
            // 子弹从敌机底部中心发射
            int bulletX = enemy.left() + enemy.width() / 2;
            int bulletY = enemy.top() + enemy.height();
            enemyBullets.push_back(QRect(bulletX, bulletY, 4, 12));
        }
    }

    // 更新敌机子弹位置，向下移动
    for (auto& bullet : enemyBullets) {
        bullet.moveTop(bullet.top() + 7); // 敌机子弹速度可稍快
    }

    // 删除超出底部的敌机子弹
    enemyBullets.erase(std::remove_if(enemyBullets.begin(), enemyBullets.end(),
                                      [this](const QRect& b) { return b.top() > height(); }), enemyBullets.end());

    // 更新子弹位置
    for (auto& bullet : bullets) {
        bullet.moveTop(bullet.top() - 5);
    }

    bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
                                 [](const QRect& b) {
                                     return b.top() < 0;
                                 }), bullets.end());


    // 我方子弹击中敌机
    for (int i = enemies.size() - 1; i >= 0; --i) {
        for (int j = bullets.size() - 1; j >= 0; --j) {
            if (enemies[i].intersects(bullets[j])) {
                enemies.removeAt(i);
                bullets.removeAt(j);
                score += 1;
                break;
            }
        }
    }
    // 敌机与我方飞机碰撞，游戏结束
    QRect playerRect(planeX, planeY, 30, 30);
    for (const auto& enemy : enemies) {
        if (enemy.intersects(playerRect)) {
            gameOver();
            break;
        }
    }
    //敌机子弹击中我方飞机
    for (int i = enemyBullets.size() - 1; i >= 0; --i) {
        if (enemyBullets[i].intersects(playerRect)) {
            enemyBullets.removeAt(i);  // 移除击中玩家的子弹
            score -= 1;
            updateScore();
            if (score < 0) {
                gameOver();           // 分数为负，游戏结束
            }
            break;
        }
    }



    update();
}

void GameWindow::keyPressEvent(QKeyEvent* event) {
    switch (event->key()) {
    case Qt::Key_W: up = true; break;
    case Qt::Key_S: down = true; break;
    case Qt::Key_A: left = true; break;
    case Qt::Key_D: right = true; break;
    case Qt::Key_Space:
        bullets.push_back(QRect(planeX + 12, planeY, 6, 12));
        break;
    case Qt::Key_Escape:
        isPaused = !isPaused;
        if (isPaused)
            gameTimer->stop();
        else
            gameTimer->start(50);
        break;
    }
}

void GameWindow::keyReleaseEvent(QKeyEvent* event) {
    switch (event->key()) {
    case Qt::Key_W: up = false; break;
    case Qt::Key_S: down = false; break;
    case Qt::Key_A: left = false; break;
    case Qt::Key_D: right = false; break;
    }
}

void GameWindow::gameOver() {
    gameOverFlag = true;
    gameTimer->stop();
}

void GameWindow::restartGame() {
    score = 0;
    enemies.clear();
    bullets.clear();
    planeX = 250;
    planeY = 300;
    gameOverFlag = false;
    gameTimer->start(50);
    update();
}

void GameWindow::updateScore() {
    scoreLabel->setText("Score: " + QString::number(score));
}
