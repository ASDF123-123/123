#ifndef GAMEWINDOW_H
#define GAMEWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include <QRect>
#include <QVector>

class QLabel;

class GameWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit GameWindow(QWidget* parent = nullptr);
    ~GameWindow();

protected:
    void paintEvent(QPaintEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    void keyReleaseEvent(QKeyEvent* event) override;

private slots:
    void updateGame();

private:
    void initUI();
    void drawGame(QPainter &painter);
    void restartGame();
    void updateScore();
    void gameOver();

private:
    QTimer* gameTimer;
    QLabel* scoreLabel;

    int planeX;
    int planeY;

    QVector<QRect> enemies;
    QVector<QRect> bullets;
    QVector<QRect> enemyBullets;

    int score;
    bool gameOverFlag;
    bool isPaused;

    // 控制飞机移动的按键状态
    bool up;
    bool down;
    bool left;
    bool right;
};

#endif // GAMEWINDOW_H
